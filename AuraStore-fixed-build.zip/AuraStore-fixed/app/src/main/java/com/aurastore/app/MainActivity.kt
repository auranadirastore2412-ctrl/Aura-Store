package com.aurastore.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF09070D)
private val Panel = Color(0xFF15111D)
private val Purple = Color(0xFF9B5CFF)
private val TextMain = Color(0xFFF5F0FA)
private val TextMuted = Color(0xFFAAA1B4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AuraStoreApp() }
    }
}

@Composable
fun AuraStoreApp() {
    var selectedMode by remember { mutableIntStateOf(15) }
    var round1 by remember { mutableIntStateOf(8) }
    var round2 by remember { mutableIntStateOf(8) }
    var running by remember { mutableStateOf(false) }
    var screen by remember { mutableStateOf("Launcher") }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg,
            surface = Panel,
            primary = Purple
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
            Column(modifier = Modifier.fillMaxSize()) {
                Header()
                when (screen) {
                    "Launcher" -> LauncherScreen(
                        selectedMode, { selectedMode = it },
                        round1, { round1 = it },
                        round2, { round2 = it },
                        running, { running = it }
                    )
                    "Store" -> StoreScreen()
                    "Log" -> LogScreen(selectedMode, running)
                    else -> SettingsScreen()
                }
                BottomBar(screen) { screen = it }
            }
        }
    }
}

@Composable
fun Header() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 18.dp)
    ) {
        Text("AURA STORE", color = TextMain, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("CONTROL CENTER", color = Purple, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun LauncherScreen(
    mode: Int, onMode: (Int) -> Unit,
    r1: Int, onR1: (Int) -> Unit,
    r2: Int, onR2: (Int) -> Unit,
    running: Boolean, onRunning: (Boolean) -> Unit
) {
    LazyColumn(
        modifier = Modifier.weight(1f).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (running) "RUNNING" else "READY", color = if (running) Purple else TextMain,
                        fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("0 / $mode", color = TextMain, fontSize = 38.sp, fontWeight = FontWeight.Bold)
                    Text("$mode APK MODE", color = TextMuted, fontSize = 12.sp)
                }
            }
        }
        item { Text("MODE LAUNCHER", color = TextMain, fontWeight = FontWeight.Bold) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                listOf(15,20,23).forEach { n ->
                    Button(
                        onClick = { onMode(n) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (mode == n) Purple else Panel
                        )
                    ) { Text("$n APK") }
                }
            }
        }
        item { Text("DELAY PUTARAN", color = TextMain, fontWeight = FontWeight.Bold) }
        item { DelayCard("Putaran 1", r1, onR1) }
        item { DelayCard("Putaran 2", r2, onR2) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(onClick = { onRunning(true) }, modifier = Modifier.weight(1f)) { Text("▶ MULAI") }
                OutlinedButton(onClick = { onRunning(false) }, modifier = Modifier.weight(1f)) { Text("■ STOP") }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(16.dp)) {
                    Text("STATUS", color = TextMain, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("Target: $mode APK", color = TextMuted)
                    Text("Putaran 1: $r1 detik", color = TextMuted)
                    Text("Putaran 2: $r2 detik", color = TextMuted)
                    Text("Monitoring: siap", color = TextMuted)
                }
            }
        }
    }
}

@Composable
fun DelayCard(label: String, value: Int, onValue: (Int) -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
        Row(
            Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, color = TextMain, fontWeight = FontWeight.Medium)
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { onValue((value - 1).coerceAtLeast(1)) }) { Text("−") }
                Text("$value detik", color = TextMain, modifier = Modifier.padding(horizontal = 12.dp))
                OutlinedButton(onClick = { onValue((value + 1).coerceAtMost(60)) }) { Text("+") }
            }
        }
    }
}

@Composable
fun StoreScreen() {
    LazyColumn(modifier = Modifier.weight(1f).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { StoreCard("🛍 Jasa Upgrade Level 20", "Tambahkan deskripsi dan harga jasa di sini.") }
        item { StoreCard("⭐ Testimoni Aura Store", "Area untuk foto dan testimoni pelanggan.") }
        item { StoreCard("📱 WhatsApp", "Tempat memasukkan nomor/link WhatsApp.") }
        item { StoreCard("📢 Channel WhatsApp", "Tempat memasukkan link channel.") }
        item { StoreCard("🌐 Media Sosial", "Instagram, TikTok, Telegram, dan lainnya.") }
    }
}

@Composable
fun StoreCard(title: String, body: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(18.dp)) {
            Text(title, color = TextMain, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(body, color = TextMuted)
        }
    }
}

@Composable
fun LogScreen(mode: Int, running: Boolean) {
    val rows = (1..mode).map { "APK ${it.toString().padStart(2,'0')}  •  BELUM DIJALANKAN" }
    LazyColumn(modifier = Modifier.weight(1f).padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        item {
            Text("LOG LAUNCHER", color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("Target $mode APK • ${if (running) "RUNNING" else "READY"}", color = TextMuted)
            Spacer(Modifier.height(8.dp))
        }
        items(rows) { row ->
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Text(row, color = TextMuted, modifier = Modifier.padding(13.dp))
            }
        }
    }
}

@Composable
fun SettingsScreen() {
    Column(modifier = Modifier.weight(1f).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("SETELAN AURA STORE", color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        StoreCard("🎨 Tema", "Nanti dapat memilih warna, foto background, logo, dan banner.")
        StoreCard("📦 Daftar APK", "Nanti dapat mengedit package 01–23 dan mengaktifkan/nonaktifkan item.")
        StoreCard("🔗 Konten Store", "Nanti dapat mengubah jasa, testimoni, WhatsApp, dan sosial media.")
    }
}

@Composable
fun BottomBar(current: String, onSelect: (String) -> Unit) {
    NavigationBar(containerColor = Panel) {
        listOf("Launcher" to "🚀", "Store" to "🛍", "Log" to "📊", "Settings" to "⚙").forEach { (name, icon) ->
            NavigationBarItem(
                selected = current == name,
                onClick = { onSelect(name) },
                icon = { Text(icon) },
                label = { Text(name) }
            )
        }
    }
}
