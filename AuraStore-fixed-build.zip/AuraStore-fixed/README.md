# AURA STORE v0.1

Fondasi awal aplikasi Android:
- Launcher mode 15 / 20 / 23 APK
- Delay Putaran 1 dan Putaran 2 terpisah
- UI dark/purple
- Halaman Store
- Halaman Log
- Halaman Settings

Catatan:
Versi ini adalah fondasi UI/configuration. Mesin untuk benar-benar membuka package lain, monitoring relog/crash/layar bermasalah, retry, dan penyimpanan konfigurasi akan ditambahkan pada tahap berikutnya setelah mekanisme izin Android pada perangkat ditentukan.

Teknologi:
- Kotlin
- Jetpack Compose
- Material 3
- Gradle
