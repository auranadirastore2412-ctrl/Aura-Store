# AURA STORE - Cloud Build

This project includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`.
It builds `app/build/outputs/apk/debug/app-debug.apk` using Java 17 and Gradle 8.9.
